var searchData=
[
  ['gyromodulequeue_5fattributes_0',['gyroModuleQueue_attributes',['../main_8c.html#a2aa761491443e7dad4e178b8af82ef83',1,'main.c']]],
  ['gyromodulequeuehandle_1',['gyroModuleQueueHandle',['../main_8c.html#a18b8971a4b2b5ffda08d5d326726a98e',1,'main.c']]],
  ['gyromoduletask_5fattributes_2',['gyroModuleTask_attributes',['../main_8c.html#aaa89319826f9f9b1be05ca84632be309',1,'main.c']]],
  ['gyromoduletaskhandle_3',['gyroModuleTaskHandle',['../main_8c.html#a2adbc23545292c938807370deb68639e',1,'main.c']]]
];
