var searchData=
[
  ['calculationqueue_5fattributes_0',['calculationQueue_attributes',['../main_8c.html#a5fdbb5a4e167b2f07ffad3085f59b22b',1,'main.c']]],
  ['calculationqueuehandle_1',['calculationQueueHandle',['../main_8c.html#a3f22ff9ce07e72c7cf160e2fe416b1af',1,'main.c']]],
  ['calculationtask_5fattributes_2',['calculationTask_attributes',['../main_8c.html#a6f2ffbf22b8c350b5d43db008b6d778a',1,'main.c']]],
  ['calculationtaskhandle_3',['calculationTaskHandle',['../main_8c.html#ab3ed9a7dfcf1ece98b8a01c5f7652b9d',1,'main.c']]]
];
