var searchData=
[
  ['usbd_5fstorage_5finterface_5ffops_5fhs_0',['usbd_storage_interface_fops_hs',['../group___u_s_b_d___s_t_o_r_a_g_e.html#ga6e9e9e24e717b09df4341124e05b6aad',1,'USBD_Storage_Interface_fops_HS:&#160;usbd_storage_if.c'],['../group___u_s_b_d___s_t_o_r_a_g_e___exported___variables.html#ga6e9e9e24e717b09df4341124e05b6aad',1,'USBD_Storage_Interface_fops_HS:&#160;usbd_storage_if.c']]]
];
