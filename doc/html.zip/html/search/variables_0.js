var searchData=
[
  ['_5f_5falign_5fend_0',['__ALIGN_END',['../group___u_s_b_d___d_e_s_c___private___variables.html#ga542bfea0b6dcf06e06a505bdc49c7e04',1,'usbd_desc.c']]]
];
