var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwx",
  1: "bcdefhlmpqstu",
  2: "_bdeghimnosu",
  3: "_abceghlrsu",
  4: "_abcdefhilmpqrstuvwx",
  5: "csu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "groups"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции",
  3: "Переменные",
  4: "Макросы",
  5: "Группы"
};

