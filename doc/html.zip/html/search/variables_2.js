var searchData=
[
  ['bridgequeue_5fattributes_0',['bridgeQueue_attributes',['../main_8c.html#a4c878e855a191cf311420900b747267a',1,'main.c']]],
  ['bridgequeuehandle_1',['bridgeQueueHandle',['../main_8c.html#ada047f338330cc148ea634481e4c9dac',1,'main.c']]],
  ['bridgetask_5fattributes_2',['bridgeTask_attributes',['../main_8c.html#a6cb2a8e4278b4fc4f32b8ac9219616b0',1,'main.c']]],
  ['bridgetaskhandle_3',['bridgeTaskHandle',['../main_8c.html#ac3a64ece4c3f0786f8bb22ef582566a8',1,'main.c']]]
];
